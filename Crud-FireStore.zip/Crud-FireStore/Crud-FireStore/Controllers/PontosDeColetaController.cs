﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Crud_FireStore.Models;
using Google.Cloud.Firestore;
using Newtonsoft.Json;

namespace Crud_FireStore.Controllers
{
    public class PontosDeColetaController : Controller
    {
        private string diretorio =
            "C:\\Users\\alqueiroz\\source\\repos\\Crud-FireStore\\Crud-FireStore\\payflow-rocketseat-aula-dri-ae482020b720.json";

        private string projetoID;
        //atrib acesar o firestore
        private FirestoreDb _firestoreDb;

        public PontosDeColetaController()
        {
            Environment.SetEnvironmentVariable("GOOGLE_APPLICATION_CREDENTIALS", diretorio);
            projetoID = "payflow-rocketseat-aula-dri";
            _firestoreDb = FirestoreDb.Create(projetoID);//instanciar 
        }

        public async Task<IActionResult> Index()
        {
            //pegar coleção
            Query pontosQuery = _firestoreDb.Collection("pontosDeColeta");
            QuerySnapshot pontosQuerySnapshot = await pontosQuery.GetSnapshotAsync();
            //List<Pontos> listPontos = new List<Pontos>();
            List<PontosDeColeta> listPontos = new List<PontosDeColeta>();

            //loop p add 
            foreach (DocumentSnapshot documentSnapshot in pontosQuerySnapshot.Documents)
            {
                //verificar se doc existe
                if (documentSnapshot.Exists)
                {
                    Dictionary<string, object> pontos = documentSnapshot.ToDictionary();
                    string json = JsonConvert.SerializeObject(pontos);
                    PontosDeColeta novosPontos = JsonConvert.DeserializeObject<PontosDeColeta>(json);
                    novosPontos.JustID = documentSnapshot.Id;
                    listPontos.Add(novosPontos);
                }

            }
            return View(listPontos);
        }

        [HttpGet]
        public IActionResult NovosPontos()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> NovosPontos(PontosDeColeta novosPontos)
        {
            CollectionReference collectionReference = _firestoreDb.Collection("pontosDeColeta");
            await collectionReference.AddAsync(novosPontos);
            return RedirectToAction(nameof(Index));
        }
    }
}
