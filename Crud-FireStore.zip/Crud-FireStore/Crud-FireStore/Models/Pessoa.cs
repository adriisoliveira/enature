﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Google.Cloud.Firestore;

namespace Crud_FireStore.Models
{
    [FirestoreData]
    public class Pessoa
    {
        public string PessoaID { get; set; }

        [FirestoreProperty]//esse já existe no firestore
        public string Nome { get; set; }
        [FirestoreProperty] 
        public string Idade { get; set; }

    }
}
