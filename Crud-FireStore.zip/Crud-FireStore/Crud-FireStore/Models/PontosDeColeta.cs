﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Google.Cloud.Firestore;

namespace Crud_FireStore.Models
{
    public class PontosDeColeta
    {
        public string JustID { get; set; }

        [FirestoreProperty]//esse já existe no firestore
        public string Nome { get; set; }
        [FirestoreProperty]
        public string Cep { get; set; }

        [FirestoreProperty]
        public string Email { get; set; }

        [FirestoreProperty]
        public string Endereço { get; set; }

        [FirestoreProperty]
        public string Estado { get; set; }

        [FirestoreProperty]
        public string Site { get; set; }

        [FirestoreProperty]
        public string Telefone { get; set; }

        [FirestoreProperty]
        public string TipoDeLixo { get; set; }
    }
}
