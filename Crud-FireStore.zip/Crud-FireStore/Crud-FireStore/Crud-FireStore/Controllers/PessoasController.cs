﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Crud_FireStore.Models;
using Google.Cloud.Firestore;
using Newtonsoft.Json;

namespace Crud_FireStore.Controllers
{
    public class PessoasController : Controller
    {
        private string diretorio =
            "H:\\Repository\\enature\\Crud-FireStore\\Crud-FireStore\\Crud-FireStore\\payflow-rocketseat-aula-dri-ae482020b720.json";

        private string projetoID;
        //atrib acesar o firestore
        private FirestoreDb _firestoreDb;

        public PessoasController()
        {
            Environment.SetEnvironmentVariable("GOOGLE_APPLICATION_CREDENTIALS", diretorio);
            projetoID = "payflow-rocketseat-aula-dri";
            _firestoreDb = FirestoreDb.Create(projetoID);//instanciar 
        }
        public async Task<IActionResult> Index()
        {
            //pegar coleção
            Query pessoasQuery = _firestoreDb.Collection("pessoas");
            QuerySnapshot pessoasQuerySnapshot = await pessoasQuery.GetSnapshotAsync();
            List<Pessoa> listPessoas = new List<Pessoa>();

            //loop p add 
            foreach (DocumentSnapshot documentSnapshot in pessoasQuerySnapshot.Documents)
            {
                //verificar se doc existe
                if (documentSnapshot.Exists)
                {
                    Dictionary<string, object> pessoa = documentSnapshot.ToDictionary();
                    string json = JsonConvert.SerializeObject(pessoa);
                    Pessoa novaPessoa = JsonConvert.DeserializeObject<Pessoa>(json);
                    novaPessoa.PessoaID = documentSnapshot.Id;
                    listPessoas.Add(novaPessoa);
                }

            }
            return View(listPessoas);
        }

        [HttpGet]
        public IActionResult NovaPessoa()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> NovaPessoa(Pessoa pessoa)
        {
            CollectionReference collectionReference = _firestoreDb.Collection("pessoas");
            await collectionReference.AddAsync(pessoa);
            return RedirectToAction(nameof(Index));
        }

        [HttpGet]
        public async Task<IActionResult> AtualizarPessoa(string pessoaID)
        {
            DocumentReference documentReference = _firestoreDb.Collection("pessoas").Document(pessoaID);
            DocumentSnapshot documentSnapshot = await documentReference.GetSnapshotAsync();

            if (documentSnapshot.Exists)
            {
                Pessoa pessoa = documentSnapshot.ConvertTo<Pessoa>();
                return View(pessoa);
            }

            return NotFound();
        }

        [HttpPost]
        public async Task<IActionResult> AtualizarPessoa(Pessoa pessoa)
        {
            DocumentReference documentReference = _firestoreDb.Collection("pessoas").Document(pessoa.PessoaID);
            await documentReference.SetAsync(pessoa, SetOptions.Overwrite);
            return RedirectToAction(nameof(Index));
        }

        [HttpPost]
        public async Task<IActionResult> ExcluirPessoa(string pessoaID)
        {
            DocumentReference documentReference = _firestoreDb.Collection("pessoas").Document(pessoaID);
            await documentReference.DeleteAsync();
            return RedirectToAction(nameof(Index));
        }
    }
}
